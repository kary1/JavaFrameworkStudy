package com.hw.entity;

public class StuCourse {
	
	private int id;
	
	private Student stu;
	private Course course;
	
	private double score;
}
