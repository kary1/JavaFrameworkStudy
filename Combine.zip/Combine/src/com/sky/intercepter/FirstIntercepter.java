package com.sky.intercepter;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import com.sky.entitys.User;

public class FirstIntercepter implements Interceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2134572084654720177L;

	@Override
	public void destroy() {
	}

	@Override
	public void init() {
	}

	@Override
	public String intercept(ActionInvocation ai) throws Exception {
		HttpSession ss = ServletActionContext.getRequest().getSession(false);
		if (ss == null) {
			return "failed";
		}
		User login = (User) ss.getAttribute("login");
//		Map<String, Object> session = ai.getInvocationContext().getSession();
//		User login = (User) session.get("login");
		if (login != null) {
			return ai.invoke();			
		}
		return "failed";
	}
}
