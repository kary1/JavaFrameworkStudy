package com.sky.action;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.sky.dao.CarDao;
import com.sky.dao.CarDaoImpl;
import com.sky.entitys.Car;
import com.sky.entitys.Car_Order;
import com.sky.entitys.Page;
import com.sky.entitys.User;

public class CarAction extends ActionSupport implements ServletRequestAware,ModelDriven<Car>{

	private static final long serialVersionUID = 8682636118021089831L;
	private String option = "first";
	private int currentPage = 1;
	private int count;
	private Car car = new Car();
	private CarDao cd = new CarDaoImpl();
	private HttpServletRequest req;
	private int car_id;
	
	public String showCar(){
		
		Page page = new Page(currentPage,count);
		List<Car> list = null;
		switch (option) {
		case "first":
			page.setCurrentPage(1);
			break;
		case "last":
			page.setCurrentPage(page.getTotalPage());
			break;
		case "prePage":
			page.prePage();
			break;
		case "nextPage":
			page.nextPage();
			break;
		}
		req.getSession().setAttribute("page", page);
		try {
			list = cd.query(page);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("cars", list);
		return "show";
	}
	
	
	
	public String add(){
		try {
			cd.insert(car);
		} catch (SQLException e) {
			e.printStackTrace();
			return "error";
		}
		return "manager";
	}
	
	public String detail(){
		Car car = null;
		try {
			car = cd.queryById(car_id);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		req.setAttribute("car", car);
		return "detail";
	}
	
	
	public String buy(){
		User user = (User) req.getSession().getAttribute("login");
		try {
			cd.buy(user.getUsername(),car_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "show";
	}
	
	public String showOrder(){
		User user = (User) req.getSession().getAttribute("login");
		List<Car_Order> order = cd.getOder(user);
		return "user_info";
	}
	
	@Override
	public Car getModel() {
		return car;
	}
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		req = arg0;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	
}
