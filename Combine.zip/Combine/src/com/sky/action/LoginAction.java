package com.sky.action;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.sky.dao.UserDao;
import com.sky.dao.UserDaoImpl;
import com.sky.entitys.User;

public class LoginAction extends ActionSupport implements ServletRequestAware,ModelDriven<User> {

	private static final long serialVersionUID = 8682636118021089831L;

	private HttpServletRequest req;
	private UserDao ud = new UserDaoImpl();
	
	private User user = new User();
	
	public String login() {
		String name = req.getParameter("name");
		String pwd = req.getParameter("pwd");
		
		User temp = null;
		try {
			temp = ud.queryByName(name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (temp != null && pwd.equals(temp.getPassword())) {
			HttpSession session = req.getSession();
			session.setAttribute("login", temp);
			if (temp.getStatus().equals("1")) {
				return "manager";
			}else{
				return "show";
			}
		}
		return "failed";
	}
	
	/**
	 * ע��
	 * @return
	 */
	public String register(){
		
		user.setStatus("0");
		try {
			ud.insert(user);
		} catch (SQLException e) {
			e.printStackTrace();
			return "register_failed";
		}
		return "login";
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		req = arg0;
	}

	@Override
	public User getModel() {
		return user;
	}

	

}
