package com.sky.dao;

import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sky.Utile.HBUtils;
import com.sky.entitys.User;


public class UserDaoImpl implements UserDao {

	@Override
	public void insert(final User user) throws SQLException {
		Session session = HBUtils.getSession();
		Transaction tx = session.beginTransaction();
		session.save(user);
		tx.commit();
	}
	
	@Override
	public User queryByName(final String name) throws SQLException {
		Session session = HBUtils.getSession();
		User user = (User) session.get(User.class, name);
		return user;
	}

}
