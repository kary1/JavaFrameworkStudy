package com.sky.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sky.Utile.HBUtils;
import com.sky.entitys.Car;
import com.sky.entitys.Car_Order;
import com.sky.entitys.Page;
import com.sky.entitys.User;

public class CarDaoImpl implements CarDao {

	@Override
	public boolean insert(Car car) throws SQLException {
		
		Session session = HBUtils.getSession();
		Transaction tx = session.beginTransaction();
		try {
			session.save(car);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		tx.commit();
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Car> query(Page page) throws SQLException {
		List<Car> list = new ArrayList<>();
		Session session = HBUtils.getSession();
		String hql = "from Car";
		list = session.createQuery(hql).setFirstResult((page.getCurrentPage() - 1) * page.getCount())
				.setMaxResults(page.getCount()).list();
		return list;
	}

	public void testInsert(Car car) throws SQLException {

		Session session = HBUtils.getSession();
		Transaction tx = session.beginTransaction();
		session.save(car);

		tx.commit();
	}

	public int getTotalRow() {
		Session session = HBUtils.getSession();
		String hql = "select count(*) from car";
		Query query = session.createSQLQuery(hql);
		int totalRow = ((Number) query.uniqueResult()).intValue();
		
		return totalRow;
	}

	@Override
	public Car queryById(int id) throws SQLException {
		Session session = HBUtils.getSession();
		
		Car car = (Car) session.get(Car.class, id);
		
		return car;
	}

	@Override
	public void buy(String username, int car_id) throws SQLException {
		Session session = HBUtils.getSession();
		Transaction tx = session.beginTransaction();
		User user = new User(username);
		Car car = new Car(car_id);
		Timestamp closingTime = new Timestamp(new Date().getTime());
		Car_Order order = new Car_Order(closingTime, 0, 26);
		order.setCar(car);
		order.setUser(user);
		session.save(order);
		tx.commit();
		session.close();
	}

	@Override
	public List<Car_Order> getOder(User user) {
		Session session = HBUtils.getSession();
		String hql = "";
		return null;
	}

}
