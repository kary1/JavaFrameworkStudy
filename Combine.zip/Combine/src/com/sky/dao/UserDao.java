package com.sky.dao;

import java.sql.SQLException;

import com.sky.entitys.User;

public interface UserDao {

	public void insert(User user)throws SQLException;

	public User queryByName(String name)throws SQLException;
}
