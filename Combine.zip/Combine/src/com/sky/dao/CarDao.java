package com.sky.dao;

import java.sql.SQLException;
import java.util.List;

import com.sky.entitys.Car;
import com.sky.entitys.Car_Order;
import com.sky.entitys.Page;
import com.sky.entitys.User;

public interface CarDao {

	public boolean insert(Car car)throws SQLException;

	public List<Car> query(Page page)throws SQLException;

	public Car queryById(int id)throws SQLException;

	public void buy(String username, int car_id)throws SQLException;

	public List<Car_Order> getOder(User user);
}
