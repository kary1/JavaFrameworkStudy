package com.sky.entitys;

import java.util.Set;

public class User {

	private String username;
	private String realName;
	private String password;
	private String telphone;
	private String status;
	private Set<Car_Order> orderSet;
	
	
	
	public User(String username) {
		super();
		this.username = username;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public User() {
		super();
	}

	public User(String username, String realname, String password, String telphone) {
		super();
		this.username = username;
		this.realName = realname;
		this.password = password;
		this.telphone = telphone;
	}

	
	
	public User(String username, String realName, String password, String telphone, String status) {
		super();
		this.username = username;
		this.realName = realName;
		this.password = password;
		this.telphone = telphone;
		this.status = status;

	}
	



	public Set<Car_Order> getOrderSet() {
		return orderSet;
	}

	public void setOrderSet(Set<Car_Order> orderSet) {
		this.orderSet = orderSet;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realname) {
		this.realName = realname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTelphone() {
		return telphone;
	}

	public void setTelphone(String telphone) {
		this.telphone = telphone;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", realName=" + realName + ", password=" + password + ", telphone="
				+ telphone + ", status=" + status + ", orderSet=" + orderSet + "]";
	}
	
	
}
