package com.sky.entitys;

import java.sql.Timestamp;

public class Car_Order {

	private int id;
	
	private User user;
	
	private Car car;
	
	private Timestamp closingTime;
	
	private int status;  //是否付款
	
	private double price; //成交价格
	
	public Car_Order() {
		super();
	}
	

	public Car_Order(Timestamp closingTime, int status, double price) {
		super();
		this.closingTime = closingTime;
		this.status = status;
		this.price = price;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}



	public Timestamp getClosingTime() {
		return closingTime;
	}



	public void setClosingTime(Timestamp closingTime) {
		this.closingTime = closingTime;
	}



	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", user=" + user + ", car=" + car + ", closingTime=" + closingTime + ", status="
				+ status + ", price=" + price + "]";
	}

}
