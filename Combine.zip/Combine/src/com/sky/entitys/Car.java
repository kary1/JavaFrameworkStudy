package com.sky.entitys;

import java.util.Set;

public class Car {

	private int id;
	private String carName;
	private double privce;
	private String massage;
	private String imageFilePath;
	private int stock;
	private Set<Car_Order> orderSet;
	
	
	
	
	public Car(int id) {
		this.id = id;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public Car() {
		super();
	}
	public Car(int id, String carName, double privce, String massage) {
		super();
		this.id = id;
		this.carName = carName;
		this.privce = privce;
		this.massage = massage;
	}
	
	
	
	public Set<Car_Order> getOrderSet() {
		return orderSet;
	}
	public void setOrderSet(Set<Car_Order> orderSet) {
		this.orderSet = orderSet;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public double getPrivce() {
		return privce;
	}
	public void setPrivce(double privce) {
		this.privce = privce;
	}
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
	
	
	public String getImageFilePath() {
		return imageFilePath;
	}
	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}
	@Override
	public String toString() {
		return "Car [id=" + id + ", carName=" + carName + ", privce=" + privce + ", massage=" + massage
				+ ", imageFilePath=" + imageFilePath + ", stock=" + stock + ", orderSet=" + orderSet + "]";
	}
	
	
}
