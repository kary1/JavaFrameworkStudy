package com.sky.entitys;

import com.sky.dao.CarDaoImpl;

public class Page {

	private static int totalRow = new CarDaoImpl().getTotalRow();
	
	private int currentPage = 1;
	private int totalPage;
	private int count = 5;
	
	public Page() {
		super();
	}
	public Page(int currentPage,int count) {
		super();
		this.currentPage = currentPage;
		totalPage = totalRow % this.count == 0 ? totalRow / this.count : totalRow / this.count + 1;
		if (count != 0) {
			this.count = count;
		}
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
	public void nextPage(){
		if (currentPage < totalPage) {
			currentPage++;
		}
	}
	public void prePage(){
		if (currentPage > 1) {
			currentPage--;
		}
	}
	public static void setTotalRow(int totalRow) {
		Page.totalRow = new CarDaoImpl().getTotalRow();
	}
}
